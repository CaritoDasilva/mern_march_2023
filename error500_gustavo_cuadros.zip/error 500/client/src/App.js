import "./App.css";
import { Routes, Route } from "react-router-dom";
import PersonForm from "./components/PersonForm";
import Container from "react-bootstrap/Container";
import ViewDetails from "./views/ViewDetails";
import SearchAllPirates from "./components/SearchAllPirates";
import styles from "./styles/Container.module.css"
import PirateForm from "./components/PirateForm";
import UpdatePirateForm from "./views/UpdatePirateForm";

function App() {
  return (
    <Container fluid="md" className={styles.colorContainer}>
      <Routes>
        <Route path="/personForm" element={<PersonForm />} />
        <Route path="/pirateForm" element={<PirateForm/>} />
        <Route path="/searAllchPirates" element={<SearchAllPirates />} />
        <Route path="/viewdetails/:id" element={<ViewDetails />} />
        <Route path="/UpdatePirateForm/:id" element={<UpdatePirateForm />} />
        <Route path="/" element={<PersonForm />}/>
      </Routes>
    </Container>
  );
}

export default App;


