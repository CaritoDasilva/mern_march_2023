import axios from "axios";

export const getAllUsers = () => axios.get('http://localhost:8000/api/users/');

export const getOneUser = (id) => axios.get(`http://localhost:8000/api/users/${id}`); 

export const createUser = (userInfo) => axios.post('http://localhost:8000/api/users/new', userInfo);

export const updateUser = (id, task) => axios.put(`http://localhost:8000/api/users/update/${id}`, task);

export const deleteUser = (id) => axios.delete(`http://localhost:8000/api/users/delete/${id}`); 

export const getAllPirate= () => axios.get('http://localhost:8000/api/pirates/');

export const getOnePirate = (id) => axios.get(`http://localhost:8000/api/pirates/${id}`); 

export const createPirate = (userInfo) => axios.post('http://localhost:8000/api/pirates/new', userInfo);

export const updatePirate = (id, task) => axios.put(`http://localhost:8000/api/pirates/update/${id}`, task);

export const deletePirate = (id) => axios.delete(`http://localhost:8000/api/pirates/delete/${id}`); 

export const userRegister = (userInfo) => axios.post('http://localhost:8000/api/user/register', userInfo);





 

