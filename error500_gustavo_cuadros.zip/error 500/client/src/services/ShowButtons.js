
const ShowButtons = (caracteristica) => {

    let inf = ({});

    if (caracteristica === "pegno" || caracteristica === "pegsi") {
        if (caracteristica === "pegno") {
          inf = { peg: "" };
        } else {
          inf = { peg: "peg" };
        }
      }
      if (caracteristica === "eyePatchno" || caracteristica === "eyePatchsi") {
        if (caracteristica === "eyePatchno") {
          inf = { eyePatch: "" };
        } else {
          inf = { eyePatch: "eyePatch" };
        }
      }
      if (caracteristica === "hookHandno" || caracteristica === "hookHandsi") {
        if (caracteristica === "hookHandno") {
          inf = { hookHand: "" };
        } else {
          inf = { hookHand: "hookHand" };
        }
      }

      return inf;

};

export default ShowButtons;

