import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Card from "react-bootstrap/Card";
import Row from "react-bootstrap/Row";
import { faker } from "@faker-js/faker";
import styles from "../styles/ViewDetails.module.css";
import { getOnePirate, updatePirate } from "../services/services";
import Button from "react-bootstrap/esm/Button";
import Col from "react-bootstrap/Col";
import {
  updateMessage,
  errorMessage,
  connectError,
} from "../utils/AlertMessages";
import ShowButtons from "../services/ShowButtons";


const ViewDetails = () => {
  const { id } = useParams();
  const [user, setUser] = useState({});
  const navigate = useNavigate();
   

  // recupera registro con id y lo muestra en pantalla

  const findOnePirate = async () => {
    try {
      const data = await getOnePirate(id);
      setUser(data.data.user);
      console.log(data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    findOnePirate();
  }, []);

 //------------------------------------------------------------------//
  const update = async (caracteristica) => {
    
    const inf = ShowButtons(caracteristica);
    
    let messageError = "";

    try {
      const data = await updatePirate(id, inf);

      if (data.data.error) {
        messageError = data.data.error.errors.description.message;

        errorMessage(messageError);
      } else {
        updateMessage();
        findOnePirate();
      }
    } catch (error) {
      connectError();
    }
  };

  //----------------------------------------------------------------------//
  return (
    user && (
      <Row className="justify-content-md-center">
        <div className={styles.header}>
          <h1>Dep Sea Davy</h1>
        </div>
        <Card style={{ width: "30rem" }} className={styles.card}>
          <Card.Img variant="top" src={faker.image.urlLoremFlickr({ category: 'pirate' })} />
          <Row>
            <Col>
              <Card.Body>
                <Card.Title>Pirata:{user.name}</Card.Title>
                <Card.Text>Position:{user.position}</Card.Text>
                <Card.Text>Treasures:{user.treasure}</Card.Text>
                <Card.Text>{user.peg}</Card.Text>
                <Card.Text>{user.eyePatch}</Card.Text>
                <Card.Text>{user.hookHand}</Card.Text>
              </Card.Body>
              <Card.Body className="text-md-center">
                <Card.Link href="/">Back Home</Card.Link>
                <Button variant="link" onClick={() => navigate(-1)}>
                  Back List
                </Button>
              </Card.Body>
            </Col>
            <Col className={styles.botones}>
              {user.peg ? (
                <button
                  name="pegno"
                  onClick={(e) => update(e.target.name)}
                  className={styles.botonNO}
                >
                  no
                </button>
              ) : (
                <button
                  name="pegsi"
                  button
                  onClick={(e) => update(e.target.name)}
                  className={styles.botonOk}
                >
                  yes
                </button>
              )}
              {user.eyePatch ? (
                <button
                  name="eyePatchno"
                  onClick={(e) => update(e.target.name)}
                  className={styles.botonNO}
                >
                  no
                </button>
              ) : (
                <button
                  name="eyePatchsi"
                  button
                  onClick={(e) => update(e.target.name)}
                  className={styles.botonOk}
                >
                  yes
                </button>
              )}
              {user.hookHand ? (
                <button
                  name="hookHandno"
                  onClick={(e) => update(e.target.name)}
                  className={styles.botonNO}
                >
                  no
                </button>
              ) : (
                <button
                  name="hookHandsi"
                  button
                  onClick={(e) => update(e.target.name)}
                  className={styles.botonOk}
                >
                  yes
                </button>
              )}
            </Col>
          </Row>
        </Card>
      </Row>
    )
  );
};

export default ViewDetails;
