import React, { useState, useEffect } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import styles from "../styles/Form.module.css";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { useNavigate, useParams } from "react-router-dom";
import { updatePirate ,getOnePirate} from "../services/services";
import {
  updateMessage,
  errorMessage,
  connectError,
} from "../utils/AlertMessages";
import { userSchemaPirate } from "../utils/ValidaForm";
import { ValidatorForm } from "../services/ValidatorForm";


const UpdatePirateForm= () => {
  const { id } = useParams();

  const [name, setName] = useState("");
  const [urlimage, setUrlimage] = useState("");
  const [treasure, setTreasure] = useState("");
  const [catchPirate, setCatchPirate] = useState("");
  const [position, setPosition] = useState("");
  const [peg, setPeg] = useState("");
  const [eyePatch, setEyePatch] = useState("");
  const [hookHand, setHookHand] = useState("");

  const navigate = useNavigate();

  const infoPirate = {
    name,
    urlimage,
    treasure,
    catchPirate,
    position,
    peg,
    eyePatch,
    hookHand,
  };
 

  //recupera el usuario con id para mostrarlo
  const findOnePirate = async () => {
    try {
      const data = await getOnePirate(id);

      const {
        name: namePirate,
        urlimage: urlImagePirate,
        treasure: treasurePirate,
        catchPirate: catchPirateT,
        position: positionPirate,
        peg: pegPirate,
        eyePatch: eyePatchPirate,
        hookHand: hookHandPirate


      } = data.data.user;
      setName(namePirate);
      setUrlimage(urlImagePirate);
      setTreasure(treasurePirate);
      setCatchPirate(catchPirateT);
      setPosition(positionPirate);
      setPeg(pegPirate);
      setEyePatch(eyePatchPirate);
      setHookHand(hookHandPirate);

    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    findOnePirate();
  }, []);

  // valida el formulario para luego guardarlo si los campos cumplen y si es correcto lo envia a grabar, sino emite mesnaje de error
  const validaForm = (e) => {
    e.preventDefault();
    ValidatorForm (userSchemaPirate,infoPirate,update);
  };
  

  // graba el registro validado y actualizado y emite mensaje de actualizado, si no pasa la validacion del front
  //pasa validar back y responde con error, si no hay error pasa a actualizar y emite mensaje, si hay error en conexion
  // en catch emite mensaje de error.
  const update = async () => {
    let messageError = "";

    try {
      const data = await updatePirate(id, infoPirate);

      if (data.data.error) {
        
          messageError = data.data.error.errors.description.message;
        

        errorMessage(messageError);
      } else {
        updateMessage();
        navigate(-1);
      }
    } catch (error) {
      connectError();
    }
  };

  return (
    <Row className="justify-content-md-center">
      <div className={styles.header}>
        <h1>Actualizar Pirata</h1>
      </div>
      <Col md={5}>
        <Form className={styles.formView}>
          <h3 className={styles.title}>Registro</h3>

          <Form.Group
            className="mb-3 text-md-start"
            controlId="name"
            as={Col}
            md="12"
          >
            <Form.Label>Pirata Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Jack Sparrow"
              onChange={(e) => setName(e.target.value)}
              value={name}
            />
          </Form.Group>

          <Form.Group className="mb-3 text-md-start" controlId="email">
            <Form.Label>Image Url</Form.Label>
            <Form.Control
              type="text"
              placeholder="http://www.JackSparrow.cl"
              onChange={(e) => setUrlimage(e.target.value)}
              value={urlimage}
            />
          </Form.Group>

          <Form.Label>Treasure Chests</Form.Label>
          <Form.Select aria-label="Default select example" onChange={(e) => setTreasure(e.target.value)}>
            <option>Open this select menu</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
          </Form.Select>
          <Form.Group className="mb-3 text-md-start" controlId="email">
            <Form.Label>Pirate Catch Phrase</Form.Label>
            <Form.Control
              type="text"
              placeholder="Nunca me arrepiento de nada"
              onChange={(e) => setCatchPirate(e.target.value)}
              value={catchPirate}
            />
          </Form.Group>
        </Form>     
      </Col>
      <Col>
      <Form onSubmit={validaForm} className={styles.formView}>
          <Form.Label>Crew Position</Form.Label>
          <Form.Select aria-label="Default select example" onChange={(e) => setPosition(e.target.value)}>
            <option>Open this select menu</option>
            <option value="First Mate">First Mate</option>
            <option value="BootsWain">BootsWain</option>
            <option value="Powder Monkey">Powder Monkey</option>
          </Form.Select>          
          <Button variant="outline-primary" type="submit">
            Actualizar
          </Button>
           <Button variant="link" onClick={() => navigate(-1)}>Back List</Button>
        </Form>
      </Col>
    </Row>
  );
};

export default UpdatePirateForm;
