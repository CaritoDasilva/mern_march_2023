import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import styles from "../styles/Form.module.css";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { useNavigate } from "react-router-dom";
import { createPirate } from "../services/services";
import { userSchemaPirate } from "../utils/ValidaForm";
import {
  correctMessage,
  errorMessage,
  connectError,
 } from "../utils/AlertMessages";
 import { ValidatorForm } from "../services/ValidatorForm";


const PirateForm = () => {
  const [name, setName] = useState("");
  const [urlimage, setUrlimage] = useState("");
  const [treasure, setTreasure] = useState("");
  const [catchPirate, setCatchPirate] = useState("");
  const [position, setPosition] = useState("");
  const [peg, setPeg] = useState("");
  const [eyePatch, setEyePatch] = useState("");
  const [hookHand, setHookHand] = useState("");

  const navigate = useNavigate();

  const infoPirate = {
    name,
    urlimage,
    treasure,
    catchPirate,
    position,
    peg,
    eyePatch,
    hookHand,
  };

  //valida el formulario para enviarlo a grabar o emitir mensaje de error
  const validaForm = (e) => {
    e.preventDefault();
    ValidatorForm (userSchemaPirate,infoPirate,onSubmitHandler);
  };

  // funcion grabar que registro que se llama desde la validacion, si aun no estan bien validados los campos, se envia a validar al back
  // si no hay error de validacion, se emite mensaje de correcto, sino se emite mensaje de error de validacion y en el catch se espera error de
  // de tipo coneccion y se muestra error.
  const onSubmitHandler = async () => {
    let messageError = "";

    try {
      const data = await createPirate(infoPirate);

      if (data.data.error) {
        
          messageError = data.data.error.errors.description.message;     
          errorMessage(messageError);
      } else {
        correctMessage();
        setName("");
        setUrlimage("");
        setCatchPirate("");
       
      }
    } catch (error) {
      connectError();
    }
  };



  return (
    <Row className="justify-content-md-center">
      <div className={styles.header}>
        <h1>Add pirata</h1>
      </div>
      <Col md={5}>
        <Form className={styles.formView}>
          <h3 className={styles.title}>Registro</h3>

          <Form.Group
            className="mb-3 text-md-start"
            controlId="name"
            as={Col}
            md="12"
          >
            <Form.Label>Pirata Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Jack Sparrow"
              onChange={(e) => setName(e.target.value)}
              value={name}
            />
          </Form.Group>

          <Form.Group className="mb-3 text-md-start" controlId="email">
            <Form.Label>Image Url</Form.Label>
            <Form.Control
              type="text"
              placeholder="httP://wwww.jacksparrow.cl"
              onChange={(e) => setUrlimage(e.target.value)}
              value={urlimage}
            />
          </Form.Group>

          <Form.Label>Treasure Chests</Form.Label>
          <Form.Select aria-label="Default select example" onChange={(e) => setTreasure(e.target.value)}>
            <option>Open this select menu</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="1">4</option>
            <option value="2">5</option>
            <option value="3">6</option>
            <option value="3">7</option>
            <option value="1">8</option>
            <option value="2">9</option>
            <option value="3">10</option>
          </Form.Select>

          <Form.Group className="mb-3 text-md-start" controlId="email">
            <Form.Label>Pirate Catch Phrase</Form.Label>
            <Form.Control
              type="text"
              placeholder="Nunca me arrepiento de nada"
              onChange={(e) => setCatchPirate(e.target.value)}
              value={catchPirate}
            />
          </Form.Group>
        </Form>     
      </Col>
      <Col>
      <Form onSubmit={validaForm} className={styles.formView}>
          <Form.Label>Crew Position</Form.Label>
          <Form.Select aria-label="Default select example" onChange={(e) => setPosition(e.target.value)}>
            <option>Open this select menu</option>
            <option value="First Mate">First Mate</option>
            <option value="BootsWain">BootsWain</option>
            <option value="Powder Monkey">Powder Monkey</option>
          </Form.Select>          
          <Row>
          <Form.Label>Peg</Form.Label>
          <input type="checkbox" id="cbox1" value="first_checkbox" onClick={(e) => setPeg("peg")}></input>
          </Row>
          <Row>
          <Form.Label>Eyepatch</Form.Label>
          <input type="checkbox" id="cbox1" value="first_checkbox" onClick={(e) => setEyePatch("eyepatch")}></input>
          </Row>
          <Row>
          <Form.Label>HookHand</Form.Label>
          <input type="checkbox" id="cbox1" value="first_checkbox" onClick={(e) => setHookHand("HookHand")}></input>
          </Row>            
          <Button variant="outline-primary" type="submit">
            Crear Pirata
          </Button> 
          <div>
          <Button variant="link" onClick={() => navigate(-1)}>Back List</Button>  
         </div>                
        </Form>
      </Col>
    </Row>
  );
};

export default PirateForm;
