import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import styles from "../styles/Form.module.css";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { useNavigate } from "react-router-dom";
import { userSchema } from "../utils/ValidaForm";
import {
  correctMessage,
  errorMessage,
  connectError,
  mensajePassword,
} from "../utils/AlertMessages";
import { ValidatorForm } from "../services/ValidatorForm";
import { userRegister } from "../services/services";

const PersonForm = () => {
  const [firstname, setfirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();
  const userInfo = {
    firstname,
    lastname,
    email,
    password,
    confirmPassword
  };
  const [emailLogin, setEmailLogin] = useState("");
  const [passwordLogin, setpasswordLogin] = useState("");

  //valida el formulario para enviarlo a grabar o emitir mensaje de error
  const validaForm = (e) => {
    e.preventDefault();
    if (password === confirmPassword) {
      ValidatorForm(userSchema, userInfo, onSubmitHandler);
    } else {
      mensajePassword();
    }
  };

  // funcion grabar que registro que se llama desde la validacion, si aun no estan bien validados los campos, se envia a validar al back
  // si no hay error de validacion, se emite mensaje de correcto, sino se emite mensaje de error de validacion y en el catch se espera error de
  // de tipo coneccion y se muestra error.
  const onSubmitHandler = async () => {
    let messageError = "";

    try {
      //setloading(true)
      //seterror(null)
      const data = await userRegister(userInfo);

      if (data.data.error) {
        if (data.data.error.keyPattern) {
          messageError = "El correo electronico ya se encuentra registrado";
        } else {
          messageError = data.data.error.errors.description.message;
        }

        errorMessage(messageError);
      } else {
        correctMessage();
        setfirstname("");
        setLastname("");
        setEmail("");
        setPassword("");
        navigate("/searAllchPirates");
      }
    } catch (error) {
         connectError(error.response.data.msg);
      //fectch  throw new Error("error") se captura en el catch
    } //finally {
         //seloading(false)
     // }
  };

  return (
    <Row className="justify-content-md-center">
      <div className={styles.header}>
        <h1>Welcome to pirata Crew</h1>
      </div>
      <Col md={5}>
        <Form onSubmit={validaForm} className={styles.formView}>
          <h3 className={styles.title}>Registro</h3>

          <Form.Group
            className="mb-3 text-md-start"
            controlId="name"
            as={Col}
            md="12"
          >
            <Form.Label>First Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="name"
              onChange={(e) => setfirstname(e.target.value)}
              value={firstname}
            />
          </Form.Group>

          <Form.Group className="mb-3 text-md-start" controlId="email">
            <Form.Label>Last Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="lastname"
              onChange={(e) => setLastname(e.target.value)}
              value={lastname}
            />
          </Form.Group>

          <Form.Group className="mb-3 text-md-start" controlId="email">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="text"
              placeholder="email"
              onChange={(e) => setEmail(e.target.value)}
              value={email}
            />
          </Form.Group>

          <Form.Group className="mb-3 text-md-start" controlId="description">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              onChange={(e) => setPassword(e.target.value)}
              value={password}
            />
          </Form.Group>

          <Form.Group className="mb-3 text-md-start" controlId="description">
            <Form.Label>Confirm Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              onChange={(e) => setConfirmPassword(e.target.value)}
              value={confirmPassword}
            />
          </Form.Group>

          <Button variant="outline-primary" type="submit">
            Registrar
          </Button>
        </Form>

        <Button variant="link" onClick={() => navigate("/")}>
          Back Home
        </Button>
      </Col>
      <Col>
        <Form onSubmit={validaForm} className={styles.formView}>
          <h3 className={styles.title}>Login</h3>

          <Form.Group
            className="mb-3 text-md-start"
            controlId="name"
            as={Col}
            md="12"
          >
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="text"
              placeholder="Esta parte no pude hacerla no entendi muy bien que hacer"
              onChange={(e) => setEmailLogin(e.target.value)}
              value={emailLogin}
            />
          </Form.Group>

          <Form.Group className="mb-3 text-md-start" controlId="email">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="text"
              placeholder="El registro si lo hice"
              onChange={(e) => setpasswordLogin(e.target.value)}
              value={passwordLogin}
            />
          </Form.Group>

          <Button variant="outline-primary" type="submit">
            Login
          </Button>
        </Form>
      </Col>
    </Row>
  );
};

export default PersonForm;
