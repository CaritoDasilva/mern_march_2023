import React, { useEffect, useState } from "react";
import { getAllPirate } from "../services/services";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import styles from "../styles/Details.module.css";
import { useNavigate, Link } from "react-router-dom";
import swal from "sweetalert";
import {deletePirate} from "../services/services"



const SearchAllUsers = () => {
  const navigate = useNavigate();
  const [totalPirates, setTotalPirates] = useState([]);
  
  // pregunta si se desea eliminar y si es si envia a la funcion grabar
  const alerta = (id) =>{  
    swal({
      title: "Eliminar?",
      text: "Estas seguro de eliminar",
      icon: "warning",
      buttons: ["No","Si"],
    }).then(respuesta =>{
       if(respuesta){
          erase(id);      
       }
    })
  }
  
  // la primera vez carga todos los registros
  const search = async () => {
    try {
      const data = await getAllPirate();

      setTotalPirates(data.data.users);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    search();
  }, []);
  
  // funcion que elimina un resgitro y emite mensaje de eliminacion
  const erase = async (id) => {
     
    try {
      const data = await deletePirate(id);
      console.log(data)
      const newPirateList = totalPirates.filter((pirates) => pirates._id !== id);
      setTotalPirates([...newPirateList]);
      swal({text: "El pirata ha sido eliminado con éxito", icon: "success"})
    } catch (error) {
      console.log(error);
    }
  }   
  


  return (
    <Row>
      <Table
        striped
        bordered
        hover
        variant="grey"
        className={styles.tableBorder}
      >
        <thead className="text-md-center">
          <tr>
            <th>View</th>
            <th>Image Url</th>
            <th># treasures</th>
            <th>Pirate Catch</th>
            <th>Crew Position</th>
            <th>Caracteristica 1</th>
            <th>Caracteristica 2</th>
            <th>Caracteristica 3</th>          
          </tr>                                  
        </thead>
        <tbody>
          {totalPirates?.map((item) => {
            return (
              <tr key={item._id}>
                <td>
                  <Link to={`/viewdetails/${item._id}`}>
                  <Button variant="primary">
                      View Pirate
                    </Button>
                  </Link>
                </td>
                <td>{item.urlimage}</td>
                <td>{item.treasure}</td>
                <td>{item.catchPirate}</td>
                <td>{item.position}</td>
                <td>{item.peg}</td>
                <td>{item.eyePatch}</td>
                <td>{item.hookHand}</td>
                <td className={styles.btn}>
                  <Link to={`/UpdatePirateForm/${item._id}`}>
                    <Button variant="warning">
                      Actualizar Pirata
                    </Button>
                  </Link>
                </td>
                <td className={styles.btn}>
                  <Button variant="danger" onClick={() => alerta(item._id)}>
                    Walk the Plank
                  </Button>{" "}
                </td>
              </tr>
            );
          })}
        </tbody>
      </Table>
      <Row>
        <Col>
          <Button variant="primary" onClick={() => navigate("/pirateForm")}>
           Add Pirate
          </Button>
        </Col>
      </Row>
    </Row>
  );
};

export default SearchAllUsers;
