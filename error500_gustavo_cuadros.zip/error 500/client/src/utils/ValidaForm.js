import * as yup from 'yup';

const nameMessage = "Nombre debe tener entre 5 y 40 carateres";
const emailMessage = "Formato de email no valido";
const passwordMessage = "Password debe tener entre 5 y 10 carateres";
const urelImageMessage = "Debe ser una Url valida"
const catchMessage = "campo catch debe tener entre 5 y 40 carateres"


//definir constantes con los mensajes

   export const userSchema = yup.object().shape({
        firstname: yup.string().typeError(nameMessage).min(5,{ message: nameMessage }).max(40,{ message: nameMessage }).matches(/^[a-zA-Z0-9_-][^#$%&()?¡]/,{ message: nameMessage }).required({message: nameMessage}),      
        lastname: yup.string().typeError(nameMessage).min(5,{ message: nameMessage }).max(40,{ message: nameMessage }).matches(/^[a-zA-Z0-9_-][^#$%&()?¡]/,{ message: nameMessage }).required({message: nameMessage}),    
        email: yup.string().typeError(emailMessage).matches(/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z-.]+$/,{ message: emailMessage}).required({ message: emailMessage}),
        password: yup.string().typeError(passwordMessage).min(5,{ message: passwordMessage}).max(10,{ message: passwordMessage }).matches(/^\w/,{ message: passwordMessage }).required({ message: passwordMessage})
    });

    export const userSchemaPirate = yup.object().shape({
      name: yup.string().typeError(nameMessage).min(5,{ message: nameMessage }).max(40,{ message: nameMessage }).matches(/^[a-zA-Z0-9_-][^#$%&()?¡]/,{ message: nameMessage }).required({message: nameMessage}),      
      urlimage: yup.string().typeError(urelImageMessage).min(5,{ message: urelImageMessage }).max(40,{ message: urelImageMessage }).matches(/^https?:\/\/[\w\-]+(\.[\w\-]+)+[/#?]?.*$/,{ message: urelImageMessage }).required({message: urelImageMessage}),    
      catchPirate: yup.string().typeError(catchMessage).min(5,{ message: catchMessage }).max(40,{ message: catchMessage }).matches(/^\w/,{ message: "campo catch treasure debe tener entre 5 y 40 carateres" }).required({ message: catchMessage})
  });
    
    
  
 //la estructura para validar los campos