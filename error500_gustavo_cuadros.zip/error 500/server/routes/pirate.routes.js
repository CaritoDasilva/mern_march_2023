const PirateController = require("../controllers/pirate.controller");

module.exports = app => {
  
  app.get("/api/pirates/", PirateController.findAllUsers);                        
  app.get("/api/pirates/:id", PirateController.findOneSingleUser);
  app.put("/api/pirates/update/:id", PirateController.updateExistingUser);
  app.post("/api/pirates/new", PirateController.createNewUser);                   
  app.delete("/api/pirates/delete/:id", PirateController.deleteAnExistingUser);
  };