const mongoose = require("mongoose");
const bcrypt = require('bcrypt');

const UserSchema = new mongoose.Schema({
	firstname:{
    type: String,
    required: [true],
    minlength: [5,"Nombre debe tener entre 5 y 40 caracteres"],
    maxlength: [40,"Nombre debe tener entre 5 y 40 caracteres"],
    },
  lastname:{
      type: String,
      required: [true],
      minlength: [5,"Apellido debe tener entre 5 y 40 caracteres"],
      maxlength: [40,"Apellido debe tener entre 5 y 40 caracteres"],
      },
  email:{
    type: String,
    unique: [true],
    required:[true],
  },
  password:{
    type: String,
    required: [true],
    minlength: [5,"Password debe tener entre 5 y 10 caracteres"],
    maxlength: [10,"Password debe tener entre 5 y 10 caracteres"],
    }
  },{ timestamps: true }
   
);

UserSchema.virtual('confirmPassword')
  .get( () => this._confirmPassword )
  .set( value => this._confirmPassword = value );

UserSchema.pre('validate', function(next) {
    if (this.password !== this.confirmPassword) {
        this.invalidate('confirmPassword', 'Contraseñas deben coincidir')
    }
    next();
});

UserSchema.pre('save', function(next) {
    bcrypt.hash(this.password, 10)
        .then(hash => {
            this.password = hash;
            next();
        })
});

const User = mongoose.model("User", UserSchema);

module.exports = User;
