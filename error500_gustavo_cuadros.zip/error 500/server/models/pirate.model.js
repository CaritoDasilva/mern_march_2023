const mongoose = require("mongoose");

const UserSchemaPirates = new mongoose.Schema({
	name:{
    type: String,
    required: [true, "Campo debe tener entre 5 y 40 caracteres"],
    minlength: [5,  "Campo debe tener entre 5 y 40 caracteres"],
    maxlength: [40, "Campo debe tener entre 5 y 40 caracteres"],
    },
    urlimage:{
    type: String,
    required: [true, "Debe ser una Url valida"],
    minlength: [5,  "Debe ser una Url valida"],
    maxlength: [40, "Debe ser una Url valida"],
    },
    treasure:{
    type: String,  
    },
    catchPirate:{
    type: String,
    required: [true, "campo treasure debe tener entre 5 y 40 carateres"],
    minlength: [5, "campo treasure debe tener entre 5 y 40 carateres"],
    maxlength: [40, "campo treasure debe tener entre 5 y 40 carateres"],
    },
    position:{
        type: String,      
    },
    peg:{
        type: String,      
    },
    eyePatch:{
        type: String,      
    },
    hookHand:{
        type: String,      
    },
    
});

const Pirate = mongoose.model("Pirate", UserSchemaPirates);

module.exports = Pirate;

