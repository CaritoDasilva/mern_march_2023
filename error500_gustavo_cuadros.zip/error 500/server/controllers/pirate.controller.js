const Pirate = require("../models/pirate.model");

module.exports.findAllUsers = (req, res) => {
    Pirate.find()
    .then(allDaUsers => res.json({ users: allDaUsers }))
    .catch(err => res.json({ error: err }));
};

module.exports.findOneSingleUser = (req, res) => {
	Pirate.findOne({ _id: req.params.id })
		.then(oneSingleUser => res.json({ user: oneSingleUser }))
		.catch(err => res.json({ error: err }));
};

module.exports.createNewUser = (req, res) => {
    Pirate.create(req.body)
    .then(newlyCreatedUser => res.json({ user: newlyCreatedUser }))
    .catch(err => res.json({ error: err }));
};

module.exports.updateExistingUser = (req, res) => {
    Pirate.findOneAndUpdate({ _id: req.params.id }, req.body, { new: true })
    .then(updatedUser => res.json({ user: updatedUser }))
    .catch(err => res.json({ error: err }));
};

module.exports.deleteAnExistingUser = (req, res) => {
    Pirate.deleteOne({ _id: req.params.id })
    .then(result => res.json({ result: "ok elimino" }))
    .catch(err => res.json({ error: err }));
};

module.exports.findOneSingleUserLogin = (req, res) => {
	Pirate.findOne({ email: req.params.email })
		.then(oneSingleUserLogin  => res.json({ user: oneSingleUserLogin }))
		.catch(err => res.json({ error: err }));
};
